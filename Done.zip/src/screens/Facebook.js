import React from 'react';
import { WebView } from 'react-native-webview';

 const Facebook = () => 
  {
    return (
            <WebView source={{ uri: 'https://www.facebook.com/netismsoft' }} />
    );
  
}

export default Facebook;

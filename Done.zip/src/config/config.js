import React from 'react';
const firebaseConfig = {
    apiKey: "AIzaSyAfXQKxeGnzBWm6J1wuJ_Uc_ahWFyI175A",
    authDomain: "gravidagbr.firebaseapp.com",
    databaseURL: "https://gravidagbr.firebaseio.com",
    projectId: "gravidagbr",
    storageBucket: "gravidagbr.appspot.com",
    messagingSenderId: "197148967822",
    appId: "1:197148967822:web:26e03bd8407a3032d4dadf",
    measurementId: "G-5LH61VCQ64"
  };
   // Initialize Firebase
   const app = firebase.initializeApp(firebaseConfig);